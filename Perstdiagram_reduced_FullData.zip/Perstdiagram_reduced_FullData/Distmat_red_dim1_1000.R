library(TDA)

files <- list.files(pattern = ".csv")
directory <-getwd()
tempor <- files

labelss <- c()
#temp <- list.files(directory, pattern = "*.csv")
for(i in seq(length(tempor))){
  print(i)
  assign(paste0("persistence", i), as.matrix(read.csv(file = paste0(directory,"/", tempor[i])), header = T)[,-1])
  labelss <- append(labelss, paste("persistence", i, sep = "_"))
}
l <- length(tempor)

Compute_N_Weight_Matrix <- function(n){
  
  assign(paste0("Weight_", n),matrix(0, nrow = l, ncol = l))
  Weight= matrix(0, l,l)
  for(i in seq(l)){
    
    for(j in seq(from=i, to=(l))){
      if(200< i & i <= 1000){
        # print(ncol(as.name(paste("var", i, sep="."))))
        ncol(get(paste("persistence", i, sep="")))
        ncol(get(paste("persistence", j, sep="")))
        entry <- bottleneck(get(paste("persistence", i, sep="")), get(paste("persistence", j, sep="")), dimension = n)
        Weight[i,j] <- entry
        #Weight[j,i] <- entry
        print(c(i,j))
      }
    }
  }
  return(assign(paste0("Weight_", n), Weight))
}

W10_dim1 <- Compute_N_Weight_Matrix(1)
write.csv(W10_dim1, File = "Dist_dim1_Full_1000.csv")


d = as.matrix(read.csv("Dist_dim1_Full_1000.csv"))[,-1]
d = d + t(d)
D = matrix(0,8528,2)
for (i in 1:8528){
  D[i,1] = mean(d[i,])
  D[i,2] = sd(d[i,])
}
write.csv(D,"reduced_bottleneck_ave_sd_dim1_Full_1000.csv")

